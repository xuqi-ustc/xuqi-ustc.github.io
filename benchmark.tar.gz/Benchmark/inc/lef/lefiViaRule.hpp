/*
 *     This  file  is  part  of  the  Cadence  LEF/DEF  Open   Source
 *  Distribution,  Product Version 5.4, and is subject to the Cadence
 *  LEF/DEF Open Source License Agreement.   Your  continued  use  of
 *  this file constitutes your acceptance of the terms of the LEF/DEF
 *  Open Source License and an agreement to abide by its  terms.   If
 *  you  don't  agree  with  this, you must remove this and any other
 *  files which are part of the distribution and  destroy any  copies
 *  made.
 *
 *     For updates, support, or to become part of the LEF/DEF Community,
 *  check www.openeda.org for details.
 */

#ifndef lefiViaRule_h
#define lefiViaRule_h

#include <stdio.h>
#include "lefiKRDefs.hpp"

class lefiViaRuleLayer {
public:
  lefiViaRuleLayer();
  void Init();

  void Destroy();
  ~lefiViaRuleLayer();

  void setName(const char* name);
  void setHorizontal();
  void setVertical();
  void setWidth(double minW, double maxW);
  void setOverhang(double d);
  void setMetalOverhang(double d);
  void setResistance(double d);
  void setSpacing(double x, double y);
  void setRect(double xl, double yl, double xh, double yh);

  int hasDirection() const ;
  int hasWidth() const ;
  int hasResistance() const ;
  int hasOverhang() const ;
  int hasMetalOverhang() const ;
  int hasSpacing() const ;
  int hasRect() const ;

  char* name() const ;
  int isHorizontal() const ;
  int isVertical() const ;
  double widthMin() const ;
  double widthMax() const ;
  double overhang() const ;
  double metalOverhang() const ;
  double resistance() const ;
  double spacingStepX() const ;
  double spacingStepY() const ;
  double xl() const ;
  double yl() const ;
  double xh() const ;
  double yh() const ;

  // Debug print
  void print(FILE* f) const;

protected:
  char* name_;
  char direction_;
  int hasWidth_;
  int hasResistance_;
  int hasOverhang_;
  int hasMetalOverhang_;
  int hasSpacing_;
  int hasRect_;
  double widthMin_;
  double widthMax_;
  double overhang_;
  double metalOverhang_;
  double resistance_;
  double spacingStepX_;
  double spacingStepY_;
  double xl_, yl_, xh_, yh_;
};



class lefiViaRule {
public:
  lefiViaRule();
  void Init();

  void clear();

  void Destroy();
  ~lefiViaRule();

  void setGenerate();

  // This should clear out all the old stuff.
  void setName(const char* name);

  // Add one of possibly many via names
  void addViaName(const char* name);

  // These routines set a part of the active layer.
  void setRect(double xl, double yl, double xh, double yh);
  void setSpacing(double x, double y);
  void setWidth(double x, double y);
  void setResistance(double d);
  void setOverhang(double d);
  void setMetalOverhang(double d);
  void setVertical();
  void setHorizontal();
  void addProp(const char* name, const char* value, const char type);

  // This routine sets and creates the active layer.
  void setLayer(const char* name);

  int hasGenerate() const ;
  char* name() const ;

  // There are 2 or 3 layers in a rule.
  // numLayers() tells how many.
  // If a third layer exists then it is the cut layer.
  int numLayers() const ;
  lefiViaRuleLayer* layer(int index);

  int numVias() const ;
  char* viaName(int index) const ;

  int numProps() const;
  const char* propName(int index) const;
  const char* propValue(int index) const;
  const char  propType(int index) const;

  // Debug print
  void print(FILE* f) const;

protected:
  char* name_;
  int nameSize_;
 
  int hasGenerate_;

  int numLayers_;
  lefiViaRuleLayer layers_[3];

  int numVias_;
  int viasAllocated_;
  char** vias_;

  int numProps_;
  int propsAllocated_;
  char** names_;
  char** values_;
  char*  types_;
};

#endif
