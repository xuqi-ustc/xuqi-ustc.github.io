/****************************************************************************/
/*                                version.h                                 */
/****************************************************************************/
/*                                                                          */
/* VERSION number of the xc library                                         */
/*                                                                          */
/* Copyright (C) 1992-1994 Tomas Skalicky. All rights reserved.             */
/*                                                                          */
/****************************************************************************/

#ifndef XC_VERSION_H
#define XC_VERSION_H

#define XC_VERSION "0.95"

#endif /* XC_VERSION_H */
