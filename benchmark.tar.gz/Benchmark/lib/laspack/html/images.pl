# LaTeX2HTML 95 (Thu Jan 19 1995)
# Associate image original text (scrambled) with physical files.

$key = q/{figure}[htb]htmlimagescale=1.5centerunitlength0.8mmpicture(156.0,119.0)thinlinesput(14.0,95.0)framebox(128.0,10.0)LargettMLSOLVput(14.0,78.0)framebox(128.0,10.0)LargettITERSOLVput(14.0,61.0)makebox(128.0,17.0)LargettRTCput(14.0,44.0)framebox(96.0,10.0)LargettPRECONDput(110.0,44.0)framebox(32.0,10.0)LargettEIGENVALput(14.0,27.0)framebox(80.0,10.0)LargettOPERATSput(94.0,27.0)framebox(48.0,10.0)LargettFACTORput(14.0,17.0)framebox(32.0,10.0)LargettVECTORput(46.0,17.0)framebox(32.0,10.0)LargettMATRIXput(78.0,17.0)framebox(64.0,10.0)LargettQMATRIXput(14.0,0.0)makebox(128.0,17.0)LargettERRHANDLthicklinesput(14.0,95.0)framebox(128.0,10.0)put(14.0,78.0)framebox(128.0,10.0)put(7.0,61.0)framebox(142.0,51.0)put(14.0,44.0)framebox(128.0,10.0)put(14.0,17.0)framebox(128.0,20.0)put(0.0,0.0)framebox(156.0,119.0)picturecenter{figure}/;
$cached_env_img{$key} ='<IMG  ALIGN=BOTTOM ALT="" SRC="img2.gif">'; 
$key = q/{_inline}$65times65${_inline}/;
$cached_env_img{$key} ='<IMG  ALIGN=MIDDLE ALT="" SRC="img1.gif">'; 

1;

